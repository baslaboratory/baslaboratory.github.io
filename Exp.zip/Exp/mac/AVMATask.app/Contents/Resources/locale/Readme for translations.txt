How to create a new translation for the AVMA task

1) Open the locale.txt file in a spreadsheet editing program (e.g. excel)
2) Create a new column for the language, and enter an appropriate abbreviation in the top row (e.g. EN, FR, NL, etc)
3) Insert the translation for each piece of text in the corresponding row.

Note the following:
1) The code looks for variable names in the left most column (so don't change this or bad things happen).
2) Text between percentage signs, e.g. %session%, is replaced by other variables at run time, so put them in the right place.
3) Pipe signs (|) are the carriage return signal (to end a line/move down a line). Multiple pipes create blanks between lines.
