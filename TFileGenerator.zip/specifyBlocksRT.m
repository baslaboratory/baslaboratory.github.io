%specifyBlocks
clear all; close all; clc;

oneToFourFirst = [1 2 5 6 9 10 13 14 17 18 21 22];   
answerKey = {[2	4 1 3],[1 3	2 4],[2 3 4 1],[3 4	1 2],[1 4 2	3],[3 1	4 2],[3	2 4	1],[1 2 4 3],[4 3 1 2],[4 2 1 3],[1	2 3	4],[3 1 2 4],[2	1 4	3],[4 3	2 1],[1	3 4	2],[2 4 3 1],[2	3 1	4],[4 2	3 1],[3	2 1	4],[3 4	2 1],[1 4 3	2],[4 1 2 3],[2 1 3 4],[4 1	3 2]};


for experiment = 1:2,
    
    for participant = 1:24
        
    clear stimArray; clear reversalArray;
       
    subjectID = participant;
    fileNum = 0;

   % fileName = '001.tfl';
    stimArray = answerKey{subjectID}(:,:);
    
    %answerKey = {[1,6,2,4,3,5], [2,5,3,1,6,4], [3,5,2,4,6,1], [4,2,5,6,3,1], [5,1,6,3,2,4], [6,2,1,3,4,5], [1, 3, 6, 2, 5, 4], [2, 6, 4, 5, 1, 3], [3, 1, 6, 4, 5, 2], [4, 3, 5, 1, 6, 2], [5, 3, 2, 1, 6, 4], [6, 5, 2, 1, 4, 3], [1, 6, 3, 5, 2, 4], [2, 5, 4, 3, 1, 6], [3, 2, 1, 6, 4, 5], [4, 1, 5, 6, 3, 2], [5, 1, 4, 2, 3, 6], [6, 4, 1, 2, 5, 3], [1, 6, 4, 2, 5, 3], [2, 5, 3, 4, 1, 6], [3, 6, 4, 2, 5, 1], [4, 3, 5, 6, 1, 2], [5, 2, 6, 3, 4, 1], [6, 2, 3, 1, 4, 5], [1, 5, 3, 4, 2, 6], [2, 4, 6, 5, 1, 3], [3, 2, 6, 4, 5, 1], [4, 3, 5, 6, 1, 2], [5, 4, 1, 6, 3, 2], [6, 3, 1, 2, 4, 5], [1, 6, 3, 5, 2, 4], [2, 4, 1, 3, 6, 5], [3, 1, 4, 5, 2, 6], [4, 1, 5, 3, 2, 6], [5, 4, 2, 1, 6, 3], [6, 4, 2, 5, 3, 1]};
    %stimArray = answerKey{subjectID}(1:4);
        
%     if experiment == 1 && ismember(subjectID,oneToFourFirst) == 0,
%        stimArray = stimArray + 10;
%     elseif experiment == 5 && ismember(subjectID,oneToFourFirst),
%        stimArray = stimArray + 10;
%     end
    
    if mod(subjectID,2) == 0 %even ID number
        %reversalArray = [answerKey{subjectID}(3), answerKey{subjectID}(5), answerKey{subjectID}(1), answerKey{subjectID}(6)];
        reversalArray = [stimArray(3) stimArray(2) stimArray(1) stimArray(4)];
    else
        %reversalArray =  [answerKey{subjectID}(5), answerKey{subjectID}(4), answerKey{subjectID}(6), answerKey{subjectID}(2)];
        reversalArray = [stimArray(1) stimArray(4) stimArray(3) stimArray(2)];
    end

    handArray = [1001 1002 1003 1004];
    rng('shuffle'); %seeds the random number generator based on the current time.
   
        %now do the if/then to figure out the number of trial files
        if experiment == 1,
            for file = 1:20
                
                %initialize trialTable
                trialTable = cell(0);
                trialTable{1} = 'phase';
                trialTable{2} = 'accCriterion';
                trialTable{3} = 'stim';
                trialTable{4} = 'button';
                trialTable{5} = 'onset';
                
                if file == 1        %practice with hand stimuli, then on to training
                     trialTable = generateBlocks(trialTable,1,'false',2,'rapid',handArray);
%                      trialTable = generateBlocks(trialTable,2,'false',2,'forced',handArray); 
%                                     %now train to criterion on symbols
                     trialTable = generateBlocks(trialTable,2,'true',1,'rapid',stimArray);
                                    %now train to criterion on symbols
                     trialTable = generateBlocks(trialTable,3,'false',10,'rapid',stimArray);
                     
                elseif file > 1 && file < 11     %daily practice and speed accuracy trade off assessment
                    trialTable = generateBlocks(trialTable,1,'false',10,'rapid',stimArray);
                    
                elseif file == 11    %switch time!
                    trialTable = generateBlocks(trialTable,1,'true',1,'rapid',reversalArray);  
                    trialTable = generateBlocks(trialTable,2,'false',10,'rapid',reversalArray);  
                                     
                elseif file >11   % daily practice and speed accuracy trade off for the revised map
                    trialTable = generateBlocks(trialTable,1,'false',10,'rapid',reversalArray);                    
                end

        %first make a directory if needed...
        subjectCode = num2str((experiment*100)+subjectID);
        if exist(num2str(subjectCode),'dir')== 7,
           cd(subjectCode);   
        else
           mkdir(subjectCode);
           cd(subjectCode); 
        end
        
        %write to file
        if file > 9
            fileName = strcat('0',num2str(file),'.tfl');
        else
            fileName = strcat('00',num2str(file),'.tfl');
        end
        
        fileID = fopen(fileName,'w');
        formatSpecHeader = '%s\t%s\t%s\t%s\t%s\r\n';
        formatSpec = '%d\t%s\t%d\t%d\t%2.3f\r\n';
        formatSpecInt = '%d\t%s\t%d\t%d\t%d\r\n';

        [nrows,ncols] = size(trialTable);
        for row = 1:nrows
            if row == 1 || trialTable{row,1} == '-'
                fprintf(fileID,formatSpecHeader,trialTable{row,:});        
            elseif trialTable{row,5} == 999,
                fprintf(fileID,formatSpecInt,trialTable{row,:});
            else    
                fprintf(fileID,formatSpec,trialTable{row,:});
            end
 
        end
       fclose(fileID);
       cd ..    
        
            end %of file run through...
        end
            
    end %write to file...

end
