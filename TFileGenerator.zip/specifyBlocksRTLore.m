%specifyBlocks
clear all; close all; clc;

oneToFourFirst = [1 2 5 6 9 10 13 14 17 18 21 22];   
answerKey = {[2	4 1 3],[1 3	2 4],[2 3 4 1],[3 4	1 2],[1 4 2	3],[3 1	4 2],[3	2 4	1],[1 2 4 3],[4 3 1 2],[4 2 1 3],[1	2 3	4],[3 1 2 4],[2	1 4	3],[4 3	2 1],[1	3 4	2],[2 4 3 1],[2	3 1	4],[4 2	3 1],[3	2 1	4],[3 4	2 1],[1 4 3	2],[4 1 2 3],[2 1 3 4],[4 1	3 2]};


for experiment = 9:9,
    
    for participant = 1:10
        
    clear stimArray; clear reversalArray;
       
    subjectID = participant;
    fileNum = 0;

   % fileName = '001.tfl';
    stimArray = answerKey{subjectID}(:,:);
    
    %this to use the "alternate" stimuli...
    stimArray = stimArray+10;
    
    if mod(subjectID,2) == 0 %even ID number
        reversalArray = [stimArray(3) stimArray(2) stimArray(1) stimArray(4)];
    else
        reversalArray = [stimArray(1) stimArray(4) stimArray(3) stimArray(2)];
    end

    handArray = [1001 1002 1003 1004];
    rng('shuffle'); %seeds the random number generator based on the current time.
   
            for file = 1:5
                
                %initialize trialTable
                trialTable = cell(0);
                trialTable{1} = 'phase';
                trialTable{2} = 'accCriterion';
                trialTable{3} = 'stim';
                trialTable{4} = 'button';
                trialTable{5} = 'onset';
                
                if file == 1        
                    %RT practice with hand stimuli
                        trialTable = generateBlocks(trialTable,1,'false',2,'rapid',handArray,2);
                    %Forced Response practice with hand stimuli
                        trialTable = generateBlocks(trialTable,1,'false',2,'forced',handArray,2);                        
                    %now train to criterion on symbols
                        trialTable = generateBlocks(trialTable,2,'true',1,'rapid',stimArray,2);
                    %now train on symbols
                        trialTable = generateBlocks(trialTable,3,'false',10,'rapid',stimArray,2);
                     
                elseif file > 1 && file < 5     
                    %daily practice with rapid trial types
                        trialTable = generateBlocks(trialTable,1,'false',10,'rapid',stimArray,2);
                                                        
                elseif file == 5  % Assessment day - match to original experiment...
                    %RT practice with hand stimuli
                        trialTable = generateBlocks(trialTable,1,'false',2,'rapid',handArray,2);
                    %Forced Response practice with hand stimuli
                        trialTable = generateBlocks(trialTable,1,'false',2,'forced',handArray,2);                        
                    %now show knowledge of original stimuli
                        trialTable = generateBlocks(trialTable,2,'true',1,'rapid',stimArray,2);                   
                    %now train to criterion on symbols
                        trialTable = generateBlocks(trialTable,3,'true',1,'rapid',reversalArray,2);
                    %final practice for 500 trials on the original symbols
                        trialTable = generateBlocks(trialTable,4,'false',5,'forced',reversalArray,2);
                end

        %first make a directory if needed...
        subjectCode = num2str((experiment*100)+subjectID);
        if exist(num2str(subjectCode),'dir')== 7,
           cd(subjectCode);   
        else
           mkdir(subjectCode);
           cd(subjectCode); 
        end
        
        %write to file
        if file > 9
            fileName = strcat('0',num2str(file),'.tfl');
        else
            fileName = strcat('00',num2str(file),'.tfl');
        end
        
        fileID = fopen(fileName,'w');
        formatSpecHeader = '%s\t%s\t%s\t%s\t%s\r\n';
        formatSpec = '%d\t%s\t%d\t%d\t%2.3f\r\n';
        formatSpecInt = '%d\t%s\t%d\t%d\t%d\r\n';

        [nrows,ncols] = size(trialTable);
        for row = 1:nrows
            if row == 1 || trialTable{row,1} == '-'
                fprintf(fileID,formatSpecHeader,trialTable{row,:});        
            elseif trialTable{row,5} == 999,
                fprintf(fileID,formatSpecInt,trialTable{row,:});
            else    
                fprintf(fileID,formatSpec,trialTable{row,:});
            end
 
        end
       fclose(fileID);
       cd ..    
        
            end %of file run through...
        end
            
    end %write to file...
