%generateTrials

function [outputTable] = generateBlocks(trialTable,phase,accuracyAssessment,nBlocks,type,stimulusArray,repeatsAllowed)

baseArray = [1 1 1 1 1 2 2 2 2 2 3 3 3 3 3 4 4 4 4 4];

    onset = '999';
    RTT = 0;
    if strcmp(type,'rapid')
        RTT = 1;
    end
    
    nBins = 5;
    
    if strcmp(accuracyAssessment,'true')
       nBins = 50; %should generate 1000 trials... 
    end
    
    
    for i = 1:nBlocks       %create a number of blocks of this type
        for j = 1:nBins     %create a number of 20 trial bins (default is 5x20, making 100 trial blocks
            
            acceptable = false; %used to check the order of the trials meets certain criteria (see below)
            
            while acceptable == false %checks sequence of stimuli against different criteria & brute forces a solution
                baseArray = baseArray(randperm(length(baseArray))); %randomize the 20 trial sequence...
                acceptable = true;  %set this to proceed if the criteria are met...
                
                if repeatsAllowed == 2
                    %1) First 2 and last 2 trials shoud not be the same stimulus (prevents long runs across sequences)
                    if baseArray(1) == baseArray(2) || baseArray(length(baseArray)-1) == baseArray(length(baseArray))
                        acceptable = false; %re-randomize the sequence
                    end
                end
                
                if repeatsAllowed < 2
                %2)  check for consecutive trials with the same stimulus...  
                    if repeatsAllowed == 1, repeatIndex = [0 0 0 0]; end
                    for k = 1:length(baseArray)-1
                        if length(unique(baseArray(k:k+1))) == 1 %if consecutive stimuli are presented
                            if repeatsAllowed == 0
                                acceptable = false;
                            else
                                %record what type of repeat this is...
                                repeatIndex(baseArray(k)) = repeatIndex(baseArray(k))+1;
                            end
                        end
                    end
                else
                    %2)  check for 3 consecutive trials with the same stimulus...  
                    if repeatsAllowed == 1, repeatIndex = [0 0 0 0]; end
                    for k = 1:length(baseArray)-2
                        if length(unique(baseArray(k:k+2))) == 1 %if 3 consecutive stimuli are presented
                            acceptable = false;
                        end
                    end
                end
                if repeatsAllowed == 1
                    %use this to fix a uniform number of repeats at 20% for each stimulus type
                    %if the final count of these repeats is not equal to 1,1,1,1 then it's not acceptable
                    if sum(repeatIndex ~= [1 1 1 1]) ~= 0
                       acceptable = false; 
                    end
                end

                %3) Every n trials must contain at least 1 of each stimulus (prevents long runs where a stimulus does not appear)
                n = 8;
                for k = 1:length(baseArray)-n
                    if unique(baseArray(k:k+n)) ~= 4, %if all 4 stimului are not used in this n trial sequence
                        acceptable = false; %re-randomize the 20 trial sequence
                    end
                end
                
                %4) the first stimulus from this segment can't be the same as the final stimulus of the last segment (i.e repeat)
                if repeatsAllowed < 2
                    if size(trialTable,1) > 1
                       %compare last trial from current segment with last stimulus entry from the trial table
                       if trialTable{size(trialTable,1),3} == stimulusArray(baseArray(20)) 
                            acceptable = false;
                       end
                    end
                end
            end
            
            for k = 1:20,
                %fill out the trial table...
                if RTT == 0;
                   onset =  rand*1.2;
                else
                    onset = 999;
                end
                               
                trialLine = cell(1,5);
                trialLine{1} = phase;
                trialLine{2} = accuracyAssessment;
                trialLine{3} = stimulusArray(baseArray(k));
                trialLine{4} = baseArray(k);
                trialLine{5} = onset;
                trialTable = [trialTable; trialLine];

                
            end
            
        end
        
        %this separates blocks
        trialLine{1} = '-';
        trialLine{2} = '-';
        trialLine{3} = '-';
        trialLine{4} = '-';
        trialLine{5} = '-';
        trialTable = [trialTable; trialLine];
        
    end 
   
    outputTable = trialTable;
    
end
